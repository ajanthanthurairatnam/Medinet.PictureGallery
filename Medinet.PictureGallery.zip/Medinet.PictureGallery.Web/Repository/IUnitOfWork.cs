﻿using Medinet.PictureGallery.Web.Models;
using System;

namespace Medinet.PictureGallery.Web.Repository
{
    public interface IUnitOfWork : IDisposable
    {
        IPictureRepository Pictures { get; }
        int Complete();
    }

    public class UnitOfWork : IUnitOfWork
    {
        private readonly PictureGalleryContext _context;
        public UnitOfWork(PictureGalleryContext context)
        {
            _context = context;
            Pictures = new PictureRepository(_context);
        }
        public IPictureRepository Pictures { get; private set; }
        public int Complete()
        {
            return _context.SaveChanges();
        }
        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
