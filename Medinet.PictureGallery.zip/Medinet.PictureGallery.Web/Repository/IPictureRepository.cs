﻿using Medinet.PictureGallery.Web.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Medinet.PictureGallery.Web.Repository
{
    public interface IPictureRepository : IGenericRepository<Picture>
    {
        IEnumerable<Picture> GetPictures(int count);
    }

    public class PictureRepository : GenericRepository<Picture>, IPictureRepository
    {
        public PictureRepository(PictureGalleryContext context) : base(context)
        {
        }

        public IEnumerable<Picture> GetPictures(int count)
        {
            return _context.Pictures.OrderByDescending(d => d.CreatedDate).Take(count).ToList();
        }
     
    }
}
