import * as React from "react";
import Camera from 'react-html5-camera-photo';
//import `react-html5-camera-photo/build/css/index.css`;

export interface HelloProps {
  compiler: string;
  framework: string;
}

function handleTakePhoto (dataUri:any) {
  // Do stuff with the photo...
  console.log('takePhoto');
}

export const Hello = (props: HelloProps) => (
  <div>
    Hello World <br />
    compiler: {props.compiler} framework: {props.framework}!
    <Camera
      onTakePhoto = { (dataUri) => { handleTakePhoto(dataUri); } }
    />
  </div>
);  
