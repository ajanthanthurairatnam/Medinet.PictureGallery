﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Medinet.PictureGallery.Web.Models;
using Medinet.PictureGallery.Web.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Medinet.PictureGallery.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PictureController : ControllerBase
    {

        private readonly IUnitOfWork _unitOfWork;
        public PictureController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IActionResult GetPictures()
        {
            var popularDevelopers = _unitOfWork.Pictures.GetPictures(100);
            return Ok(popularDevelopers);
        }

        public IActionResult GetPicture(int Id)
        {
            var popularDevelopers = _unitOfWork.Pictures.GetById(Id);
            return Ok(popularDevelopers);
        }

        [HttpPost]
        public IActionResult AddPicture([FromBody]Picture picture)
        {
            _unitOfWork.Pictures.Add(picture);
            _unitOfWork.Complete();
            return Ok();
        }
    }
}