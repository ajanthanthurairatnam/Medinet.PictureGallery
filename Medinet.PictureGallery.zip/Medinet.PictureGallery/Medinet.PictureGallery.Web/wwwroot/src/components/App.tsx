import * as React from "react";
import Camera from 'react-html5-camera-photo';
import { useState } from "react";
import { ISubmitPhotoForm } from "./ISubmitPhotoForm";
import { SubmitPhotoForm } from "./SubmitPhotoForm";

export const App = () => {

  const [showSubmitPhotoForm, setSubmitPhotoForm] = useState<ISubmitPhotoForm>({ dataUri: '', showSubmitPhotoForm: false });

  const handleTakePhoto = (dataUri: string) => 
  {
    setSubmitPhotoForm({ showSubmitPhotoForm: !showSubmitPhotoForm, dataUri: dataUri });
  }


  return (
    <div>
      <Camera
        onTakePhoto={(dataUri) => { handleTakePhoto(dataUri); }}
      />
      <SubmitPhotoForm {...showSubmitPhotoForm} />

    </div>
  )
};


