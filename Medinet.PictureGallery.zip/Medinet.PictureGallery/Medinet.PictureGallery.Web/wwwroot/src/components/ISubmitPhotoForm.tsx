export interface ISubmitPhotoForm {
  showSubmitPhotoForm: boolean;
  dataUri: string;
}
