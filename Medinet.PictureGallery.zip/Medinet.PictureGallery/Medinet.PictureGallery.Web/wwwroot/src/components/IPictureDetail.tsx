export interface IPictureDetail {
  id: number;
  showPictureDetail: boolean;
}
