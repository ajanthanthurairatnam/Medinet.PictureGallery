import * as React from "react";
import { useState } from "react";
import * as $ from 'jquery';
import { ISubmitPhotoForm } from "./ISubmitPhotoForm";
import { Gallery } from "./Gallery";

export const SubmitPhotoForm = (props: ISubmitPhotoForm) => {
    const [showGallery, setShowGallery] = useState<boolean>(false);
    const [title, setTitle] = useState<string>('');
    const [description, setDescription] = useState<string>('');

    const handleSubmit = () => {
        $.post("api/Picture/AddPicture", { title: title, description: description, image: `data:image/png;base64,` + props.dataUri })
            .done(setShowGallery(!showGallery));
    };
    return (<div>
        <div>
            <img src={`data:image/png;base64,` + props.dataUri} />

        </div>
        <div>
            Title

     </div>
        <div>

            <input type="text" onChange={(e) => setTitle(e.target.value)} />

        </div>

        <div>
            Description

     </div>
        <div>

            <input type="text" onChange={(e) => setDescription(e.target.value)} />

        </div>


        <div>
            Submit
   <button onClick={() => handleSubmit}>Submit</button>
        </div>

        <Gallery {...showGallery} />

    </div>);
};
