import * as React from "react";
import * as $ from 'jquery';
import { useState, useEffect } from "react";
import { PictureDetail } from "./PictureDetail";
import { IPictureDetail } from "./IPictureDetail";
import { IPicture } from "./IPicture";

export const Gallery = (showGallery: boolean) => {
    const [Pictures, setPictures] = useState<IPicture[]>([]);
    const [PicDetail, setPictureDetail] = useState<IPictureDetail>(null);

    useEffect(() => {
        getAllPictures();
    }, []);

    const getAllPictures = () => {
        $.getJSON("api/Picture/GetPictures", function (pics: IPicture[]) {
            setPictures(pics)
        });
    }

    const showDetail = (props: IPictureDetail) => {
        setPictureDetail({ id: props.id, showPictureDetail: props.showPictureDetail });
    }


    return (showGallery && Pictures.length > 0 && <div>
        {Pictures.map((picture, index) => (
            <img key={index} onClick={() => showDetail({ id: picture.id, showPictureDetail: true })}
                src={`data:image/png;base64,` + picture.image} />
        ))}
        <PictureDetail {...PicDetail} />
    </div>);
};
