export interface IPicture {
  id: number;
  image: string;
  title:string;
  description:string;
}
