import * as React from "react";
import * as $ from 'jquery';
import { useState, useEffect } from "react";
import { IPictureDetail } from "./IPictureDetail";
import { IPicture } from "./IPicture";

export const PictureDetail = (props: IPictureDetail) => {
  const [Picture, setPicture] = useState<IPicture>(null);
  const { id, showPictureDetail } = { ...props }

  useEffect(() => {
    getPicture(id);
  }, []);

  const getPicture = (id) => {
    $.getJSON(`api/Picture/GetPicture?id=` + id, function (pic: IPicture) {
      setPicture(pic)
    });
  }


  return (showPictureDetail && <div>
    <h3>{Picture.title}</h3>
    <div>Image</div>
    <div>
      <img src={`data:image/png;base64,` + Picture.image} />

    </div>
    <div>
      {Picture.description}
    </div>


  </div>);
};
