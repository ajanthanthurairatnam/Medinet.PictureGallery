﻿using Microsoft.EntityFrameworkCore;

namespace Medinet.PictureGallery.Web.Models
{
    public class PictureGalleryContext : DbContext
    {
        public PictureGalleryContext(DbContextOptions<PictureGalleryContext> options) : base(options) { }

        public DbSet<Picture> Pictures { get; set; }
    }
}
